export const LOGINDATA_DRA = "Containers/LOGINDATA_DRA";

export const LOGINDATA_API = `${BBaseUrl}/me?type=thumbnail`;
