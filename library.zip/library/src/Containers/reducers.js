import { fromJS } from "immutable";
import { LOGINDATA_DRA } from "./constant";
import initialJSState from "./initialState";

const initialState = fromJS(initialJSState);

function loginReducer(state = initialState, action) {
  switch (action.type) {
    case LOGINDATA_DRA:
      return state.set("isDataFetching", true).set("isDataFetched", false);
  }
}

export default loginReducer;
