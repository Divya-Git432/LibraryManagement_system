import { LOGINDATA_DRA } from "../constant";

export function login(datapack) {
  return {
    type: LOGINDATA_DRA,
    datapack,
  };
}
