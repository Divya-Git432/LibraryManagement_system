// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getfireStore } from "@firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAZOsg6_xpHS6WoG1xVx0blOIyp1XGnTyY",
  authDomain: "test-bee8c.firebaseapp.com",
  databaseURL: "https://test-bee8c.firebaseio.com",
  projectId: "test-bee8c",
  storageBucket: "test-bee8c.appspot.com",
  messagingSenderId: "336811001322",
  appId: "1:336811001322:web:e8d9fd9d6f576713979e93",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const firestore = getfireStore(app);
