import React, { Fragment, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../CSS/Style.css";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loggedIn, setLoggedIn] = useState(false);
  const Navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      //const response = await fetch("https://myapi.com/login", {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/users",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            username: username,
            password: password,
          }),
        }
      );

      const data = await response.json();
      setLoading(false);
      console.log(data); // This will log the response from the API to the console
      //if (data.success) {
      if (data.username === "divya") {
        setLoggedIn(true);
        Navigate("/User");
      } else {
        setError("Invalid username or password");
      }
    } catch (error) {
      setLoading(false);
      console.error(error); // This will log any errors to the console
      setError("An error occurred. Please try again later.");
    }
    if (loggedIn === true) {
      console.log("you are loggedin");
    }
  };
  return (
    <Fragment>
      <div className="login-page">
        <h1>User Login</h1>
        {error && <p className="error">{error}</p>}
        <form onSubmit={handleSubmit} className="form">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            required
          />

          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            required
            pattern=".{8,}"
          />

          <button type="submit" disabled={loading}>
            {loading ? "Loading..." : "Login"}
          </button>
        </form>
        <p>
          Don't have an account? <Link to="/Register">Register here</Link>.
        </p>
      </div>
      <Link to="http://localhost:3000/">Go back to login page</Link>
    </Fragment>
  );
}

export default Login;
