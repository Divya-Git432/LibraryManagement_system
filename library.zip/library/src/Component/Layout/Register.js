import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
//import axios from "axios";

function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [MobileNumber, setMobileNumber] = useState("");

  const Navigate = useNavigate();
  const handleSubmit = (event) => {
    event.preventDefault();
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
      username: username,
      password: password,
    });

    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    };

    fetch("http://localhost:8080/api/register", requestOptions)
      .then((response) => response.text())
      .then((result) => {
        alert("Registered Successfully!!!");
        Navigate("/AdminLogin");
      })
      .catch((error) => console.log("error", error));
  };

  return (
    <div className="register-page">
      <h1>Register</h1>
      <form onSubmit={handleSubmit} className="form">
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          required
        />

        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
        />

        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
          pattern=".{8,}"
        />

        <label htmlFor="MobileNumber">Mobile Number:</label>
        <input
          type="tel"
          id="MobileNumber"
          value={MobileNumber}
          onChange={(event) => setMobileNumber(event.target.value)}
          required
        />

        <button type="submit">Register</button>
      </form>
      <p>
        Already have an account? <Link to="/Login">Login here</Link>.
      </p>
    </div>
  );
}

export default Register;
