import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  //const [loggedIn, setLoggedIn] = useState(false);
  // const history = useHistory();
  const Navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    /*//https://jsonplaceholder.typicode.com/users
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/users",
        {
          //const response = await fetch("/api/authaccount/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            username: username,
            password: password,
          }),
        }
      );

      const data = await response.json();
      setLoading(false);
      console.log(data); // This will log the response from the API to the console
      //if (data.success) {
      if (data.username === "Bret") {
        setLoggedIn(true);
        Navigate("/AdminPage");
      } else {
        setError("Invalid username or password");
      }
    } catch (error) {
      setLoading(false);
      console.error(error);
      setError("An error occurred. Please try again later.");
    }
  };
 */
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
      username: username,
      password: password,
    });

    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    };

    fetch("http://localhost:8080/api/login", requestOptions)
      .then((response) => response.text())
      .then((result) => {
        result = JSON.parse(result);
        console.log(result);
        console.log(result.token);
        if (result.token === undefined || result.token === "") {
          alert("UNAUTHORISED");
        } else {
          localStorage.setItem("token", result.token);
          alert("Login success");
          Navigate("/AdminPage");
        }
      })
      .catch((error) => console.log("error", error));
  };

  return (
    <div className="login-page">
      <h1>Admin Login</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit} className="form">
        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          required
        />

        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
          pattern=".{6,}"
        />

        <button type="submit" disabled={loading}>
          {loading ? "Loading..." : "Login"}
        </button>

        <div className="ForgotPassword ">
          ForgotPassword ?<Link to="/ForgotPassword ">Forgot Password </Link>
        </div>
      </form>
      <p>
        Don't have an account? <Link to="/Register">Register here</Link>.
      </p>
    </div>
  );
}

export default AdminLogin;
