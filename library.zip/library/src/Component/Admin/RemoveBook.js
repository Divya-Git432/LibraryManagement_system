import React, { useState } from "react";
import "./AdminPage.css";

const RemoveBook = () => {
  const [bookId, setBookId] = useState("");

  const handleInputChange = (event) => {
    setBookId(event.target.value);
  };

  const handleRemoveBook = async () => {
    try {
      var myHeaders = new Headers();
      myHeaders.append(
        "Authorization",
        `Bearer ${localStorage.getItem("token")}`
      );

      var formdata = new FormData();
      formdata.append("title", "1234543");

      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: formdata,
        redirect: "follow",
      };

      fetch(`http://localhost:8080/admin/delete/${bookId}`, requestOptions)
        .then((response) => response.text())
        .then((result) => {
          alert("Removed Successfully!!!");
        })
        .catch((error) => console.log("error", error));
    } catch (error) {
      console.log(error);
      alert("Failed to remove book");
    }
  };

  return (
    <div className="form-container">
      <h2>Remove Book</h2>
      <div className="input-group">
        <label htmlFor="book-id">Book ID:</label>
        <input
          type="text"
          id="book-id"
          value={bookId}
          onChange={handleInputChange}
          placeholder="Enter book ID"
          required
        />

        <button className="remove-button" onClick={handleRemoveBook}>
          Remove Book
        </button>
      </div>
    </div>
  );
};

export default RemoveBook;
