import React, { useState } from "react";
import { Link } from "react-router-dom";

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setLoading(false);
    setSuccess(true);
  };

  if (success) {
    return (
      <div className="forgot-password-page">
        <p>
          An email has been sent to {email} with instructions on how to reset
          your password.
        </p>
        <p>
          <Link to="/AdminLogin">Back to login</Link>
        </p>
      </div>
    );
  }

  return (
    <div className="forgot-password-page">
      <h1>Forgot Password</h1>
      <p>
        Enter your email address below and we'll send you a link to reset your
        password.
      </p>
      <form onSubmit={handleSubmit} className="form">
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          required
        />

        <button type="submit" disabled={loading}>
          {loading ? "Loading..." : "Reset Password"}
        </button>
      </form>
      <p>
        <Link to="/AdminLogin">Back to login</Link>
      </p>
    </div>
  );
}

export default ForgotPassword;
