import React, { useState } from "react";
import BookList from "../Book/BookList";
import AddBook from "./AddBook";
import RemoveBook from "./RemoveBook";
import UserList from "./UserList";
import "./AdminPage.css";

const AdminPage = () => {
  const [activeTab, setActiveTab] = useState("bookList");
  const [searchText, setSearchText] = useState("");

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  const handleSearchInputChange = (event) => {
    setSearchText(event.target.value);
  };

  const handleLogout = () => {
    window.location.href = "http://localhost:3000/";
  };

  return (
    <div className="librarian-page">
      <div className="header">
        <h1>ReadEase Library -Admin Page</h1>
        <button type="Logout" onClick={handleLogout}>
          Logout
        </button>
      </div>
      <div className="tab-menu">
        <button
          className={activeTab === "bookList" ? "active" : ""}
          onClick={() => handleTabClick("bookList")}
        >
          Book List
        </button>
        <button
          className={activeTab === "addBook" ? "active" : ""}
          onClick={() => handleTabClick("addBook")}
        >
          Add Book
        </button>
        <button
          className={activeTab === "removeBook" ? "active" : ""}
          onClick={() => handleTabClick("removeBook")}
        >
          Remove Book
        </button>
        <button
          className={activeTab === "userList" ? "active" : ""}
          onClick={() => handleTabClick("userList")}
        >
          User List
        </button>
        <div className="search-container">
          <input
            type="text"
            placeholder="Search books..."
            value={searchText}
            onChange={handleSearchInputChange}
          />
          <button>Search</button>
        </div>
      </div>
      <div className="tab-content">
        {activeTab === "bookList" && <BookList searchText={searchText} />}
        {activeTab === "addBook" && <AddBook />}
        {activeTab === "removeBook" && <RemoveBook />}
        {activeTab === "userList" && <UserList />}
      </div>
    </div>
  );
};

export default AdminPage;
