import React, { useState, useEffect } from "react";
//import axios from "axios";

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    var myHeaders = new Headers();
    myHeaders.append(
      "Authorization",
      `Bearer ${localStorage.getItem("token")}`
    );

    var formdata = new FormData();

    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: formdata,
      redirect: "follow",
    };

    fetch("http://localhost:8080/admin/view-readers", requestOptions)
      .then((response) => response.text())
      .then((result) => {
        result = JSON.parse(result);
        console.log(result.readers);
        setUsers(result.readers);
      })
      .catch((error) => console.log("error", error));
  }, []);

  return (
    <div className="book-list">
      <h2>User List</h2>
      <table>
        <thead>
          <tr>
            <th>User Name</th>
            <th>Balance</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.username}>
              <td>{user.username}</td>
              <td>{user.wallet}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UserList;
