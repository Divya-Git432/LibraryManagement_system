import React, { useState } from "react";
import BookList from "./UserBookList";
import BorrowedBooks from "../Book/BorrowedBooks";
import Payment from "./Payment";

const User = () => {
  const [activeTab, setActiveTab] = useState("bookList");
  const [searchText, setSearchText] = useState("");

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  const handleSearchInputChange = (event) => {
    setSearchText(event.target.value);
  };

  const handleLogout = () => {
    // perform any necessary cleanup, e.g. clearing local storage or session data
    // redirect the user to the login page
    window.location.href = "http://localhost:3000/";
  };

  return (
    <div className="user-page">
      <div className="header">
        <h1>ReadEase Library -User Page</h1>
        <button type="Logout" onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className="tab-menu">
        <button
          className={activeTab === "bookList" ? "active" : ""}
          onClick={() => handleTabClick("bookList")}
        >
          Book List
        </button>
        <button
          className={activeTab === "borrowedBooks" ? "active" : ""}
          onClick={() => handleTabClick("borrowedBooks")}
        >
          Borrowed Books
        </button>
        <button
          className={activeTab === "Payment" ? "active" : ""}
          onClick={() => handleTabClick("Payment")}
        >
          Payment
        </button>

        <div className="search-container">
          <input
            type="text"
            placeholder="Search books..."
            value={searchText}
            onChange={handleSearchInputChange}
          />
          <button>Search</button>
        </div>
      </div>
      <div className="tab-content">
        {activeTab === "bookList" && <BookList searchText={searchText} />}
        {activeTab === "borrowedBooks" && <BorrowedBooks />}
        {activeTab === "Payment" && <Payment />}
      </div>
    </div>
  );
};

export default User;
