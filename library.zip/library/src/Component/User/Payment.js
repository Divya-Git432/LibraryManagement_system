import React, { useState, useEffect } from "react";
//import "../Admin/AdminPage.css";

const Payment = () => {
  const [Returnbooks, setReturnBooks] = useState([]);

  useEffect(() => {
    fetchReturnBooks();
  }, []);

  const fetchReturnBooks = async () => {
    try {
      const response = await fetch(
        "http://localhost:8080/books/pending-payment",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const data = await response.json();
      console.log(data.booklist);
      setReturnBooks(data.booklist);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <section className="return-list">
      <table>
        <thead>
          <tr>
            <th>Book ID</th>
            <th>Issue Date</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {Returnbooks !== null &&
            Returnbooks !== undefined &&
            Returnbooks.length >= 0 &&
            Returnbooks.map((item) => (
              <tr key={item.id}>
                <td>{item.bookid}</td>
                <td>{item.issuedate}</td>
                <td>{item.amount}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </section>
  );
};

export default Payment;
