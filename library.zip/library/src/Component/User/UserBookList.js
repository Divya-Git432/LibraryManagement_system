import React, { useState, useEffect } from "react";
//import AddBook from "../Admin/AddBook";
import "../Admin/AdminPage.css";

const UserBookList = () => {
  const [books, setBooks] = useState([]);
  const BorrowHandler = (event) => {
    var requestOptions = {
      method: "GET",
      redirect: "follow",
    };

    let tempArray = books;
    tempArray = tempArray.filter((temp) => temp.id !== event);
    setBooks([...tempArray]);

    fetch(`http://localhost:8080/books/borrow/${event}`, requestOptions)
      .then((response) => response.text())
      .then((result) => {
        result = JSON.parse(result);
        alert(result.message);
      })
      .catch((error) => console.log("error", error));
  };
  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await fetch("http://localhost:8080/books", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      console.log(data);
      setBooks(data.books);
    } catch (error) {
      console.error(error);
    }
  };

  // const addBook = (book) => {
  //   setBooks([...books, book]);
  // };

  return (
    <div className="book-list">
      <h2>Book List</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Count</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id} onClick={() => BorrowHandler(book.id)}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.count}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* <AddBook AddBook={addBook} /> */}
    </div>
  );
};

export default UserBookList;
