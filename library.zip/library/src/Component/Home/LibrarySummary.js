import React from "react";
import "../CSS/Style.css";

const LibrarySummary = () => {
  return (
    <section className="summary">
      <h2>Knowledge is free, come and get it..,</h2>
      {/* <p>
        Libraries are not just buildings filled with books. They are community
        centers, gathering places, and hubs of knowledge.{" "}
      </p>
      Libraries offer something for everyone, from children's storytimes to book
      clubs for adults, from access to technology and databases to resources for
      job seekers.
      <p></p> */}
    </section>
  );
};

export default LibrarySummary;
