import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import "../CSS/Style.css";

import LibraryImage from "../../assets/library.jpeg";
import LibrarySummary from "./LibrarySummary";

const Home = (props) => {
  return (
    <Fragment>
      <header className="Home">
        <h1>ReadEase Library</h1>
        <Link to="/Login">
          <button type="LoginRegister">User</button>
        </Link>
        <Link to="/AdminLogin">
          <button type="AdminLogin"> Admin</button>
        </Link>
      </header>
      <div className="main-image">
        <img src={LibraryImage} alt=" "></img>
      </div>
      <LibrarySummary />
    </Fragment>
  );
};

export default Home;
