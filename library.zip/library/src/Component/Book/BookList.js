import React, { useState, useEffect } from "react";
//import AddBook from "../Admin/AddBook";
import "../Admin/AdminPage.css";

const BookList = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetchBooks();
  }, [books]);

  const fetchBooks = async () => {
    try {
      const response = await fetch("http://localhost:8080/books", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      console.log(data);
      setBooks(data.books);
    } catch (error) {
      console.error(error);
    }
  };

  // const addBook = (book) => {
  //   setBooks([...books, book]);
  // };

  return (
    <div className="book-list">
      <h2>Book List</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Count</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.count}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* <AddBook AddBook={addBook} /> */}
    </div>
  );
};

export default BookList;
