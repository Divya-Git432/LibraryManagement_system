import React, { useState, useEffect } from "react";
import "../Admin/AdminPage.css";

function BorrowedBooks() {
  const [books, setBooks] = useState([]);

  const ReturnHandler = (event) => {
    var requestOptions = {
      method: "GET",
      redirect: "follow",
    };

    let tempArray = books;
    tempArray = tempArray.filter((temp) => temp.id !== event);
    setBooks([...tempArray]);

    fetch(`http://localhost:8080/books/return/${event}`, requestOptions)
      .then((response) => response.text())
      .then((result) => {
        result = JSON.parse(result);
        alert(result.message);
      })
      .catch((error) => console.log("error", error));
  };

  async function fetchData() {
    try {
      var requestOptions = {
        method: "GET",
        redirect: "follow",
      };

      fetch("http://localhost:8080/reader/borrowedBooks/1", requestOptions)
        .then((response) => response.text())
        .then((result) => {
          result = JSON.parse(result);
          setBooks(result.books);
        });
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="book-list">
      <h2>Borrowed Books</h2>
      <table>
        <thead>
          <tr>
            <th>Book-ID</th>
            <th>Issue-Date </th>
            <th>Predicted</th>
          </tr>
        </thead>
        <tbody>
          {books !== null &&
            books !== undefined &&
            books.length >= 0 &&
            books.map((book) => (
              <tr key={book.bookid} onClick={() => ReturnHandler(book.bookid)}>
                <td>{book.bookid} </td>
                <td>{book.issuedate}</td>
                <td> Rs {book.amount}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export default BorrowedBooks;
