import Home from "./Component/Home/Home";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Login from "./Component/Layout/Login";
import Register from "./Component/Layout/Register";
import AdminLogin from "./Component/Layout/AdminLogin";
import AdminPage from "./Component/Admin/AdminPage";
import ForgotPassword from "./Component/Admin/ForgotPassword";
import User from "./Component/User/User";
import Payment from "./Component/User/Payment";

function App() {
  return (
    <Router>
      <div className="app-container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/AdminLogin" element={<AdminLogin />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/User" element={<User />} />
          <Route path="/Register" element={<Register />} />
          <Route path="/AdminPage" element={<AdminPage />} />
          <Route path="/Forgotpassword" element={<ForgotPassword />} />
          <Route path="/Payment" element={<Payment />} />
        </Routes>
      </div>
      {/* <LibrarySummary /> */}
    </Router>
  );
}

export default App;
